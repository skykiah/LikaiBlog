---
title: MySQL 执行加载顺序
author: Alex
top: false
hide: false
cover: false
toc: true
mathjax: false
categories: MySQL
tags:
  - MySQL
abbrlink: 3b8d5b86
date: 2021-07-30 23:26:09
img:
coverImg:
password:
summary:
---

# MySQL 执行加载顺序

> 这篇文章算是 "水" 一下吧，本想以文字的方式展示出来的，发现以文字的方式写出来太乱了，刚好找到了几张截图，索性就直接截图了。截图也更加清晰明了。

- MySQL 手写 sql 时的语句

![MySQL 手写 sql 时的语句](https://upload-images.jianshu.io/upload_images/14623749-c265c44851c61cbe.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

- MySQL 机读 sql 顺序

![MySQL 机读 sql 顺序](https://upload-images.jianshu.io/upload_images/14623749-f245cb1b54a6a9a7.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

- MySQL 执行顺序

![MySQL 执行顺序](https://upload-images.jianshu.io/upload_images/14623749-9c169ebd6af288dc.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

